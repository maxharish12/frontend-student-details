package com.algorythm.attendance_tracker

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class StudentDetailsScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.student_details_screen)

    }
}