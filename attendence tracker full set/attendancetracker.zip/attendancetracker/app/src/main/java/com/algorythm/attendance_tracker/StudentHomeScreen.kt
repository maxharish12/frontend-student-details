package com.algorythm.attendance_tracker

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class StudentHomeScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.student_home_screen)

    }
}