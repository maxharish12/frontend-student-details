package com.algorythm.attendance_tracker

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class TeacherHomeScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.teacher_home_screen)

    }
}