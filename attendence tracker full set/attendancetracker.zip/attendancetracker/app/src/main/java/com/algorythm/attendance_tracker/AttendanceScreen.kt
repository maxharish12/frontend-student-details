package com.algorythm.attendance_tracker

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class AttendanceScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.attendance_screen)


    }
}